<?php
include 'config.php';

// Mengatur jumlah data per halaman
$items_per_page = 10;

// Mendapatkan halaman saat ini dari URL, default ke 1 jika tidak ada
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $items_per_page;

// Mengambil data dari database dengan limit dan offset
$sql = "SELECT * FROM PETUGAS_PENDAFTARAN LIMIT $items_per_page OFFSET $offset";
$result = $conn->query($sql);

// Menghitung total data
$total_sql = "SELECT COUNT(*) as total FROM PETUGAS_PENDAFTARAN";
$total_result = $conn->query($total_sql);
$total_row = $total_result->fetch_assoc();
$total_items = $total_row['total'];
$total_pages = ceil($total_items / $items_per_page);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Petugas Pendaftaran</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* CSS untuk menyesuaikan tinggi baris tabel */
        .table th, .table td {
            padding: 0.3rem; /* Mengurangi padding untuk baris yang lebih kecil */
            vertical-align: middle; /* Menyelaraskan vertikal konten */
            font-size: 0.9rem; /* Ukuran font yang lebih kecil */
        }
        .table thead th {
            background-color: #007bff; /* Warna biru untuk header */
            color: white; /* Warna teks putih */
        }
        .table {
            margin-bottom: 0; /* Mengurangi margin bawah tabel */
        }
        .page-item.active .page-link {
            background-color: #007bff;
            border-color: #007bff;
        }
    </style>
</head>
<body>
<div class="container mt-4">
    <h2>Data Petugas Pendaftaran</h2>
    <a href="create.php" class="btn btn-primary mb-4">Tambah Petugas</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID Petugas</th>
                <th>Nama Petugas</th>
                <th>No Telepon</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $row["ID_PETUGAS"] . '</td>';
                    echo '<td>' . $row["NAMA_PETUGAS"] . '</td>';
                    echo '<td>' . $row["NO_TELP"] . '</td>';
                    echo '<td>
                            <a href="update.php?id=' . $row["ID_PETUGAS"] . '" class="btn btn-warning btn-sm">Edit</a>
                            <a href="delete.php?id=' . $row["ID_PETUGAS"] . '" class="btn btn-danger btn-sm">Delete</a>
                          </td>';
                    echo '</tr>';
                }
            } else {
                echo '<tr><td colspan="4">No data found</td></tr>';
            }
            ?>
        </tbody>
    </table>

    <!-- Pagination -->
    <nav aria-label="Page navigation">
        <ul class="pagination">
            <?php if ($page > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="index.php?page=<?php echo $page - 1; ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
            <?php else: ?>
                <li class="page-item disabled">
                    <span class="page-link">&laquo;</span>
                </li>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                    <a class="page-link" href="index.php?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                </li>
            <?php endfor; ?>

            <?php if ($page < $total_pages): ?>
                <li class="page-item">
                    <a class="page-link" href="index.php?page=<?php echo $page + 1; ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            <?php else: ?>
                <li class="page-item disabled">
                    <span class="page-link">&raquo;</span>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
</div>
</body>
</html>
