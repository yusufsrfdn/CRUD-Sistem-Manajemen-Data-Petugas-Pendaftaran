<?php
include 'config.php';

// Mendapatkan data dari formulir
$id_petugas = $_POST['id_petugas'];
$nama_petugas = $_POST['nama_petugas'];
$no_telp = $_POST['no_telp'];

// Query untuk memasukkan data
$sql = "INSERT INTO PETUGAS_PENDAFTARAN (ID_PETUGAS, NAMA_PETUGAS, NO_TELP) VALUES ('$id_petugas', '$nama_petugas', '$no_telp')";

try {
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Petugas berhasil ditambahkan'); window.location.href = 'index.php';</script>";
    } else {
        throw new Exception($conn->error);
    }
} catch (mysqli_sql_exception $e) {
    if ($conn->errno === 1062) { // Error code for duplicate entry
        echo "<script>alert('Error: ID Petugas sudah ada.'); window.location.href = 'create.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "'); window.location.href = 'create.php';</script>";
    }
} catch (Exception $e) {
    echo "<script>alert('Error: " . $e->getMessage() . "'); window.location.href = 'create.php';</script>";
}

$conn->close();
?>
