<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $id = $_GET['id'];

    $sql = "DELETE FROM PETUGAS_PENDAFTARAN WHERE ID_PETUGAS = '$id'";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Petugas berhasil dihapus'); window.location.href = 'index.php';</script>";
    } else {
        echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "'); window.location.href = 'index.php';</script>";
    }

    $conn->close();
}
?>
