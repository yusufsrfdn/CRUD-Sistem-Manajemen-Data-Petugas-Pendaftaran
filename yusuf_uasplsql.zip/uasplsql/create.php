<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Petugas</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2>Tambah Petugas</h2>
    <form action="create_proses.php" method="POST">
        <div class="form-group">
            <label for="id_petugas">ID Petugas:</label>
            <input type="text" class="form-control" id="id_petugas" name="id_petugas" required>
        </div>
        <div class="form-group">
            <label for="nama_petugas">Nama Petugas:</label>
            <input type="text" class="form-control" id="nama_petugas" name="nama_petugas" required>
        </div>
        <div class="form-group">
            <label for="no_telp">No Telp:</label>
            <input type="text" class="form-control" id="no_telp" name="no_telp" required>
        </div>
        <button type="submit" class="btn btn-primary">Tambah</button>
    </form>
    <a href="index.php" class="btn btn-secondary mt-3">Kembali</a>
</div>
</body>
</html>
