<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id_petugas'];
    $nama_baru = $_POST['nama_petugas'];
    $no_telp_baru = $_POST['no_telp'];

    $sql = "UPDATE PETUGAS_PENDAFTARAN
    SET NAMA_PETUGAS = '$nama_baru', NO_TELP = '$no_telp_baru'
    WHERE ID_PETUGAS = '$id'";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Petugas berhasil diperbarui'); window.location.href = 'index.php';</script>";
    } else {
        echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "'); window.location.href = 'update.php?id=$id';</script>";
    }

    $conn->close();
}
?>
