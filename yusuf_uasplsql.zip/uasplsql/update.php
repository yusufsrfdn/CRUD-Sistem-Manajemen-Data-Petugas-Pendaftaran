<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $id = $_GET['id'];
    $sql = "SELECT * FROM PETUGAS_PENDAFTARAN WHERE ID_PETUGAS = '$id'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perbarui Petugas</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2>Perbarui Petugas</h2>
    <form action="update_proses.php" method="post">
        <div class="form-group">
            <label for="id_petugas">ID Petugas:</label>
            <input type="text" class="form-control" id="id_petugas" name="id_petugas" value="<?php echo $row['ID_PETUGAS']; ?>" readonly>
        </div>
        <div class="form-group">
            <label for="nama_petugas">Nama Petugas Baru:</label>
            <input type="text" class="form-control" id="nama_petugas" name="nama_petugas" value="<?php echo $row['NAMA_PETUGAS']; ?>" required>
        </div>
        <div class="form-group">
            <label for="no_telp">No Telp Baru:</label>
            <input type="text" class="form-control" id="no_telp" name="no_telp" value="<?php echo $row['NO_TELP']; ?>" required>
        </div>
        <button type="submit" class="btn btn-warning">Perbarui</button>
    </form>
    <a href="index.php" class="btn btn-secondary mt-4">Kembali</a>
</div>
</body>
</html>
